import json
import os

def handler(event, context):
    target_bucket = os.environ.get('AUDIT_BUCKET_TARGET')
    env = os.environ.get('ENVIRONMENT')
    
    print(f"🔍 [EVALUACIÓN] Procesando registros de auditoría en el bucket: {target_bucket}")
    print(f"🛠️ Entorno de ejecución: {env}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'SUCCESS',
            'message': 'Registro de transacciones validado e indexado correctamente',
            'bucket_asociado': target_bucket
        })
    }
