import json
def lambda_handler(event, context):
    for record in event['Records']:
        body = json.loads(record['body'])
        if 'Message' in body:
            sns_message = json.loads(body['Message'])
            if 'Records' in sns_message:
                s3_info = sns_message['Records'][0]['s3']
                print(f"🚀 [TF-PROCESADOR] ¡Nuevo archivo detectado!")
                print(f"📁 Bucket: {s3_info['bucket']['name']}")
                print(f"📄 Archivo: {s3_info['object']['key']}")
                print(f"⚖️ Tamaño: {s3_info['object']['size']} bytes")
    return {'statusCode': 200, 'body': json.dumps('Procesado')}
